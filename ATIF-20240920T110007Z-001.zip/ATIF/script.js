// Mock Database
let students = [];
let marksData = [];

function addStudent() {
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const email = document.getElementById('studentEmail').value;
    const password = document.getElementById('studentPassword').value;
    const cnic = document.getElementById('studentCNIC').value;

    if (firstName && lastName && email && password && cnic) {
        const student = {
            id: students.length + 1,
            firstName,
            lastName,
            email,
            password,
            cnic,
            userType: 'Student'
        };

        students.push(student);
        updateStudentTable();
        updateStudentSelect();
        clearStudentFields();
        alert('Student added successfully!');
    } else {
        alert('Please fill in all fields.');
    }
}

function updateStudentTable() {
    const studentTableBody = document.querySelector('#studentTable tbody');
    studentTableBody.innerHTML = ''; // Clear existing rows

    students.forEach((student, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${student.firstName}</td>
            <td>${student.lastName}</td>
            <td>${student.email}</td>
            <td>${student.cnic}</td>
            <td><button onclick="removeStudent(${index})">Delete</button></td>
        `;
        studentTableBody.appendChild(row);
    });
}

function updateStudentSelect() {
    const studentSelect = document.getElementById('studentIdMarks');
    studentSelect.innerHTML = '<option value="">Select Student</option>'; // Clear existing options

    students.forEach((student) => {
        const option = document.createElement('option');
        option.value = student.id;
        option.text = `${student.firstName} ${student.lastName} (ID: ${student.id})`;
        studentSelect.appendChild(option);
    });
}

function removeStudent(index) {
    students.splice(index, 1);
    updateStudentTable();
    updateStudentSelect();
    alert('Student removed successfully!');
}

function clearStudentFields() {
    document.getElementById('firstName').value = '';
    document.getElementById('lastName').value = '';
    document.getElementById('studentEmail').value = '';
    document.getElementById('studentPassword').value = '';
    document.getElementById('studentCNIC').value = '';
}

function uploadMarks() {
    const studentId = document.getElementById('studentIdMarks').value;
    const course = document.getElementById('course').value;
    const marks = document.getElementById('marks').value;
    const totalMarks = document.getElementById('totalMarks').value;
    const grade = document.getElementById('grade').value;

    if (studentId && course && marks && totalMarks && grade) {
        const markEntry = {
            studentId,
            course,
            marks,
            totalMarks,
            grade
        };

        marksData.push(markEntry);
        updateMarksTable();
        clearMarksFields();
        alert('Marks uploaded successfully!');
    } else {
        alert('Please fill in all fields.');
    }
}

function updateMarksTable() {
    const marksTableBody = document.querySelector('#marksTable tbody');
    marksTableBody.innerHTML = ''; // Clear existing rows

    marksData.forEach((mark) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${mark.studentId}</td>
            <td>${mark.course}</td>
            <td>${mark.marks}</td>
            <td>${mark.totalMarks}</td>
            <td>${mark.grade}</td>
        `;
        marksTableBody.appendChild(row);
    });
}

function clearMarksFields() {
    document.getElementById('studentIdMarks').value = '';
    document.getElementById('course').value = '';
    document.getElementById('marks').value = '';
    document.getElementById('totalMarks').value = '';
    document.getElementById('grade').value = '';
}
